﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class Download_CheckInPage : Form
    {
        public Download_CheckInPage()
        {
            InitializeComponent();
        }

        private void EventDashboardLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
