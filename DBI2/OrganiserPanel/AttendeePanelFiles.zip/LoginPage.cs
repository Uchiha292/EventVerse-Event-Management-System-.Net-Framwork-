﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Login_Click(object sender, EventArgs e)
        {
            /*SqlConnection conn = new SqlConnection("Data Source=HAMZA\\SQLEXPRESS;Initial Catalog=FacebookDB;Integrated Security=True"); //Connection String
            conn.Open();
            MessageBox.Show("Connection Open");
            SqlCommand cm;
            string un = textBox1.Text;
            string pass = textBox2.Text;
            string query = "Insert into Facebook_Users(Username, Password) values ('" + un + "','" + pass + "')";
            cm = new SqlCommand(query, conn);
            cm.ExecuteNonQuery();
            cm.Dispose();
            conn.Close();*/

            using (SqlConnection conn = new SqlConnection("Data Source=HAMZA\\SQLEXPRESS;Initial Catalog=FacebookDB;Integrated Security=True"))
            {
                conn.Open();

                string un = textBox1.Text;
                string pass = textBox2.Text;

                string[] nameParts = un.Split(' ');

                string firstName = nameParts.Length > 0 ? nameParts[0] : "";
                string lastName = nameParts.Length > 1 ? nameParts[1] : "";

                string query = "SELECT COUNT(*) FROM Facebook_SignUp WHERE CAST(First_name AS NVARCHAR(MAX)) = @First_name AND CAST(Last_name AS NVARCHAR(MAX)) = @Last_name AND CAST(Password AS NVARCHAR(MAX)) = @Password";

                using (SqlCommand cm = new SqlCommand(query, conn))
                {
                    cm.Parameters.AddWithValue("@First_name", firstName);
                    cm.Parameters.AddWithValue("@Last_name", lastName);
                    cm.Parameters.AddWithValue("@Password", pass);

                    int result = (int)cm.ExecuteScalar();

                    if (result > 0)
                    {
                        string insertQuery = "INSERT INTO Facebook_Users (Username, Password) VALUES (@Username, @Password)";

                        using (SqlCommand insertCommand = new SqlCommand(insertQuery, conn))
                        {
                            insertCommand.Parameters.AddWithValue("@Username", un);
                            insertCommand.Parameters.AddWithValue("@Password", pass);

                            int rowsAffected = insertCommand.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Login Successful");
                            }
                            else
                            {
                                MessageBox.Show("Login Successful, but failed to record data");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password");
                        AttendeeMainPage attendeePage = new AttendeeMainPage();
                        attendeePage.Show();
                    }
                }
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            RegisterPage signPage = new RegisterPage();
            signPage.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}
